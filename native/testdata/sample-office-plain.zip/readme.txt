just a zip of text files
